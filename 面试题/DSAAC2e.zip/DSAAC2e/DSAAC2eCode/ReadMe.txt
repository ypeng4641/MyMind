Since The "fatal.h" is used in many examples, if you build an example project, you need to copy "fatal.h" to you project.
